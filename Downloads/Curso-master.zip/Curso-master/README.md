# Curso
Todo lo aprendido (actualizandose)
Cosas aprendidas:
Esquema lógico
Pseudocódigo
If, If Else, Else
