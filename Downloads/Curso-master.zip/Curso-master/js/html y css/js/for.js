/* Vamos a crear un programa que nos salude si le damos permiso, si tienes permiso, llora.*/
// con la notación "/*" sirve para comentar en más de una linea, se debe cerrar con "*/".

var permiso;

permiso=false;

	if (permiso === true) {document.write("Hola, ¿Te pago el Uber?")}
	if (permiso === false) {document.write("<div>Sad</div>")}
