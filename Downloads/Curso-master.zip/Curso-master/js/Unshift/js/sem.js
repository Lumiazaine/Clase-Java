// Dado un Array de marcas de coches
// 1)Añadir una primera marca al principio
// 2)Sacar el resultado por la consola.
// Push es para el final, push para el principio.
var aCoches = ["Skoda","Mercedes","Opel","Ferrari"];
aCoches.unshift("Renault")
console.log(aCoches)