var 
fuerzaOrco=4;
fuerzaElfo=1;
if (fuerzaOrco>fuerzaElfo) {"El orco gana"}
	else if (fuerzaOrco<fuerzaElfo) {"El elfo gana"}
		else {"Empate"}
