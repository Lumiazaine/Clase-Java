// Puedo juntar las variables en una misma linea con una "," bastánte útil. Ejemplo "var fuerzaOrco, fuerzaElfo" uwu
//Comparaciones "=="
//Asignaciones "="
// API = Application Programming Interface

	var fuerzaOrco; // Variable Orco.
	var fuerzaElfo; // Variable Elfo.

// Entrada de datos
	
	fuerzaOrco=8;
	fuerzaElfo=8;
		if (fuerzaOrco == fuerzaElfo) {
		alert ("No gana nadie")
		}

//el resultado será "No gana nadie", por lo que el programa se acaba allí.