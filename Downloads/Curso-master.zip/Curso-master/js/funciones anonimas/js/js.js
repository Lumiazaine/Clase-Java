// var miNumero = 5;
// var miObjeto = {nombre:"pepa"};
// var miArray = [2,3,4];

// var miFuncion = function(){alert("hola mundo")};
// miFuncion();

var orco={

	fuerza:200,
	color:"#ee3456",
	ataque:function(){alert("GROWOLLLLLL")};
}

orco.fuerza=300;
orco.ataque();
