// dado un array con 4 frutas 
// 1) añadid al final otra fruta
// 2) sacar el resultado por la consola
// Push sirve para añadir contenido
var aFrutas = ["Fresas","Melocotones","Pera","Manzanas"];
console.log(aFrutas);
aFrutas.push("Melón"); 
console.log(aFrutas);
aFrutas.push("Platanos","Limones","Uvas");
console.log(aFrutas);
