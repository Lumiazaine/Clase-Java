// Crear un objeto persona y asignarle dos propiedades: nombre y edad.
// escribir en el documento dos propiedades utilizando las dos notaciones que nos proporciona javascript.

var persona = {
	nombre:"Pepa",
	edad:1,
}

document.write(persona.nombre);
document.write(persona["edad"]);