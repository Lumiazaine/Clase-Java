// Dadas 3 provicncias en un Array:
// *Eliminar la primera
// *Eliminar de nuevo la primera
// *Sacar el resultado en un alert
var aProvincias = ["Burgos","Sevilla","Madrid"];
aProvincias.shift();
console.log(aProvincias);
aProvincias.shift();
console.log(aProvincias);
alert ("Solo queda " +aProvincias)
