// Hacer un programa que nos salude 100 veces.

for ( var i = 1 ; i <= 100 ; i++ ) {
	// alert ("HOLA")
	document.write ("<div class='rojo fuente'>HOLA " +i+"</div>");
}
