var escuderías={

		mercedes:{
			
			color_linea:"#00d2be",
			nombre_escuderia:"Mercedes",
			bandera:"bandera_alemania.png"
			logotipo:"logo_mercedes.jpg",
			foto_coche:"coche_mercedes.jpg",
			numero_podios:"162",
			campeonatos_ganados:"5",
			anos_campeonatos_ganados:["2014","2015","2016","2017","2018","2019"],
			pilotos:{
				
				piloto1:"Lewis Hamilton",
				piloto2:"Valtteri Bottas"
			}





		},
		ferrari:{



		},
		redbull:{




		},


};